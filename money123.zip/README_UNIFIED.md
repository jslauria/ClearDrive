# OneDrive File Organizer - UNIFIED VERSION

**All features in one application** - Scans your ENTIRE OneDrive!

Written and designed by **Jeffery Lauria**  
For support: **jeff@Brokencomputer.net**

---

## 🎯 Key Features

✅ **Full OneDrive Scan** - Recursively scans ALL folders and subfolders  
✅ **Device Code Authentication** - Simple browser-based login  
✅ **AI-Powered Categorization** - Smart file organization (optional)  
✅ **Archive Feature** - Auto-archive items 24+ months old  
✅ **Clean Up Empty Folders** - Remove empty folders after organizing  
✅ **Large File Support** - Handle ISO, executables, disk images  
✅ **Safe Operation** - Never deletes files, only moves  

## 🆕 What's New

### Full OneDrive Scan
Scans **your entire OneDrive**, not just root-level files:
- ✅ Scans ALL folders recursively
- ✅ Finds files buried in subdirectories
- ✅ Shows file paths during processing
- ✅ Organizes everything into clean root-level folders

### Clean Up Empty Folders (NEW!)
After organizing, automatically removes empty folders left behind:
- ✅ Deletes empty folders recursively
- ✅ Preserves organized category folders
- ✅ Preserves Archive folder
- ✅ Multiple passes to clean nested empty folders

## 📦 Quick Start

1. **Download all files** to one folder:
   - START_ORGANIZER.bat
   - onedrive_organizer_unified_gui.py
   - onedrive_organizer_unified.py
   - requirements.txt

2. **Double-click** `START_ORGANIZER.bat`

3. **Authenticate:**
   - Click "Connect to OneDrive"
   - Copy the device code shown
   - Visit the URL and paste code
   - Sign in with Microsoft 365 account

4. **Configure options:**
   - (Optional) Enter Anthropic API key
   - ☐ Include large files
   - ☑ Archive old files (enter months)
   - ☑ **Clean up empty folders** ← NEW!

5. **Click "Start Organizing"**

## 🗂️ Archive Feature

Archives files/folders not accessed in X months (default 24) to `Archive/YEAR/`

**Archive Structure:**
```
Archive/
  ├── 2023/  ← Items last accessed in 2023
  ├── 2022/
  └── 2021/
```

## 🧹 Clean Up Empty Folders

After moving all files, the cleanup feature:

1. Scans entire OneDrive for empty folders
2. Deletes empty folders (except Archive and organized categories)
3. Repeats until no empty folders remain
4. Logs every deletion

**Example:**
```
Before cleanup:
  /Old Projects/           (empty)
  /Random/Downloads/temp/  (empty)
  /Photos/2020/            (empty)

After cleanup:
  (All empty folders removed)
```

## 🔍 How It Works

### 1. Full Scan Phase
```
Scanning entire OneDrive...
  Scanning: /
  Scanning: /Projects/
  Scanning: /Projects/2024/
  ...
Found 1,247 items
```

### 2. Organization Phase
```
Processing files...
[1/856] /Projects/2024/report.pdf
  → Documents
[2/856] /Random/invoice.pdf
  → Financial
...
```

### 3. Archive Phase (if enabled)
```
Processing folders for archiving...
Old folder (not accessed in 36 months)
  → Archive/2021/
```

### 4. Cleanup Phase (if enabled)
```
Cleaning up empty folders...
Pass 1:
  Found empty: /Random/Downloads/temp/
  ✓ Deleted empty folder
Pass 2:
  Found empty: /Random/Downloads/
  ✓ Deleted empty folder
Pass 3:
  No more empty folders found
```

## ⚙️ Options

**Include large files:**
- ☐ Skip files >10MB (default)
- ☑ Process ISO, executables, disk images

**Archive old files:**
- ☐ Organize all files normally (default)
- ☑ Move old items to Archive/YEAR/
- Enter months (12, 24, 36, etc.)

**Clean up empty folders:**
- ☐ Leave empty folders (default)
- ☑ Delete empty folders after organizing

## 📋 Requirements

- Python 3.7+
- Microsoft 365 / Business account
- Internet connection

## 📄 Files Included

- **START_ORGANIZER.bat** - Launcher
- **onedrive_organizer_unified_gui.py** - GUI
- **onedrive_organizer_unified.py** - Engine  
- **requirements.txt** - Dependencies

## 🎬 Example Result

**Before (messy):**
```
OneDrive/
  ├── Old Projects/
  │   └── 2020/
  │       └── report.docx
  ├── Random/
  │   └── Downloads/
  │       └── temp/
  │           └── invoice.pdf
  └── Photos/
      └── Vacation/
          └── 2023/
              └── beach.jpg
```

**After (organized with cleanup):**
```
OneDrive/
  ├── Documents/
  │   └── report.docx
  ├── Financial/
  │   └── invoice.pdf
  └── Photos/
      └── beach.jpg

(All empty folders removed)
```

## 🛡️ Safety

- **Nothing deleted** - only moved (files)
- **Empty folders removed** - if cleanup enabled
- **Full logging** - every action recorded
- **Reversible** - manually move files back if needed
- **Protected folders** - Archive and organized categories preserved

## 💡 Tips

- **First run without cleanup** to see what gets organized
- **Review results** before enabling cleanup
- **Check Activity Log** for detailed progress
- **Enable cleanup** once comfortable with organization

## 🎯 What Gets Organized

✅ All files from anywhere in OneDrive  
✅ Files in subdirectories at any depth  
✅ Documents, images, videos, archives  
✅ Spreadsheets, presentations, PDFs  

## 🗑️ What Gets Deleted (Cleanup Only)

✅ Empty folders after files moved  
✅ Nested empty folder structures  

❌ Archive folder (preserved)  
❌ Organized category folders (preserved)  
❌ Folders with any content (preserved)  

---

**Written and designed by Jeffery Lauria**  
For support: **jeff@Brokencomputer.net**

This unified version scans your ENTIRE OneDrive and organizes everything!
